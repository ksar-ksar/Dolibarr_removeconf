# CHANGELOG REMOVECONF FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## 1.0.1
Bug on Invoice Valid, the action is valid and not validate

## 1.0
Initial version working with V9


