# CHANGELOG REMOVECONF FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## 2.0.0
Thanks to Akene, add user permissions instead of gloabl permission to this module.
This allows to better control who can  by-pass the confirmation pop-up

## 1.0.2
Bug on order and Customer Invoice Validation in case of warehouse

## 1.0.1
Bug on Invoice Valid, the action is valid and not validate

## 1.0
Initial version working with V9


